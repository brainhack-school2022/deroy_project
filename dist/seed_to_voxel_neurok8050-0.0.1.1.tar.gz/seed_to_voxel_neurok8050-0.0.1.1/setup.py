from distutils.core import setup

setup(name='seed_to_voxel',
      version='0.0.1.1',
      description='This package is to be used for seed to voxel correlation application',
      author='Claudéric DeRoy Xanthy Lajoie',
      author_email='clauderic.deroy@umontreal.ca xanthy.lajoie@umontreal.ca',
      url='https://github.com/brainhack-school2022/deroy_project'
)
