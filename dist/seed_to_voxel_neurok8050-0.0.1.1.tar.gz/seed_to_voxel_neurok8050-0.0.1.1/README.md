# deroy_project

Hi my name is Claudéric.

I am an graduate student at University of Montréal, I am doing a master in Psychology.
My project is on the evaluation of computer program for preprocessing electrodermal activity (EDA).

<a href="https://github.com/neurok8050">
   <img src="https://avatars.githubusercontent.com/u/44348995?v=4?s=100" width="100px;" alt=""/>
   <br /><sub><b>Claudéric DeRoy</b></sub>
</a>